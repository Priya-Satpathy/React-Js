import "./Product.css"

export default function Product(props){
    const name = props.name;
    const price = props.price;
    const type = props.type;

    return(
        <div className="product">
            <h1>{name}</h1>
            <h3>{type}</h3>
            <h3>MRP ₹{price}</h3>
        </div>
    )
}