import { useState } from "react"
import Product from "./Component/Product"

function App() {
  const [show, changeShow] = useState('')

  function product1(){
    changeShow(<Product name = "Nike Dunk Low Retro" type = "Men's Shoe" price = {8295}/>)
  }
  function product2(){
    changeShow(<Product name = "Nike Vaporfly 3 Electric" type = "Road Running Shoe" price = {21385}/>)
  }
  function product3(){
    changeShow(<Product name = "Nike Zoom Vomero 5" type = "Men's Shoe" price = {14995}/>)
  }

  return (
    <>
      <button onClick={product1}>Product 1</button>
      <button onClick={product2}>Product 2</button>
      <button onClick={product3}>Product 3</button>
      <div>{show}</div>
    </>
  )
}

export default App
