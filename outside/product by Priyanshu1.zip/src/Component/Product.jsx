import "./Product.css"

export default function Product(props){
    const name = props.name;
    const price = props.price;
    const type = props.type;
    const className = props.className

    return(
        <div className= {className}>
            <h1>{name}</h1>
            <h3>{type}</h3>
            <h3>{price}</h3>
        </div>
    )
}