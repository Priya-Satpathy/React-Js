import { useState } from "react"
import Product from "./Component/Product"

function App() {
  const [name, changeName] = useState('')
  const [type, changeType] = useState('')
  const [price, changePrice] = useState('')
  const [className, AddClassName] = useState('')

  function product1(){
    changeName("Nike Dunk Low Retro")
    changeType("Men's Shoe")
    changePrice("MRP: ₹"+8295)
    AddClassName('product')
  }
  function product2(){
    changeName("Nike Vaporfly 3 Electric")
    changeType("Road Running Shoe")
    changePrice("MRP: ₹"+21385)
    AddClassName('product')
  }
  function product3(){
    changeName("Nike Zoom Vomero 5")
    changeType("Men's Shoe")
    changePrice("MRP: ₹"+14995)
    AddClassName('product')
  }

  return (
    <>
      <button onClick={product1}>Product 1</button>
      <button onClick={product2}>Product 2</button>
      <button onClick={product3}>Product 3</button>
      <Product name = {name} type = {type} price = {price} className = {className}/>
    </>
  )
}

export default App
